package shipley.c492project.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import shipley.c492project.model.Part;
import shipley.c492project.model.InHouse;
import shipley.c492project.model.Outsourced;

public class Inventory {

    public Inventory(){}
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    public static void addPart(Part newPart){
        allParts.add(newPart);
    }

    public static void addProduct(Product newProduct){
        allProducts.add(newProduct);
    }

    public static ObservableList<Part> lookupPartID(String partID) {
        ObservableList<Part> partsFound = FXCollections.observableArrayList();
        ObservableList<Part> all = getAllParts();
        for (Part part : all) {
            if(part.getId().contains(partID))
            {
                partsFound.add(part);
            }
        }
        return partsFound;
    }

    public static ObservableList<Product> lookupProductID(String productID) {
        ObservableList<Product> productsFound = FXCollections.observableArrayList();
        ObservableList<Product> all = getAllProducts();
        for (Product product : all) {
            if (product.getId().contains(productID))
            {
                productsFound.add(product);
            }
        }
        return productsFound;
    }

    public static ObservableList<Part> lookupPart(String partName) {

        ObservableList<Part> partsFound = FXCollections.observableArrayList();
        ObservableList<Part> all = getAllParts();
        for (Part part : all) {
            if(part.getName().contains(partName))
            {
                partsFound.add(part);
            }
        }
        return partsFound;
    };

    public static ObservableList<Product> lookupProductName(String productName) {
        ObservableList<Product> productsFound = FXCollections.observableArrayList();
        ObservableList<Product> all = getAllProducts();
        for (Product product : all) {
            if (product.getName().contains(productName))
            {
                productsFound.add(product);
            }
        }
        return productsFound;
    };

    public static void updatePart (int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }

    public static void updateProduct(int index, Product selectedProduct){
        allProducts.set(index, selectedProduct);
    }

    public static boolean deletePart(Part selectedPart){
        if(allParts.contains(selectedPart)){
            allParts.remove(selectedPart);
            return true;
        }
        else{
            return false;
        }
    }

    public static boolean deleteProduct(Product selectedProduct){
        if(allProducts.contains(selectedProduct)){
            allProducts.remove(selectedProduct);
            return true;
        }
        else{
            return false;
        }
    }
    public static ObservableList<Part> getAllParts(){
        return allParts;
    }
    public static ObservableList<Product> getAllProducts(){
        return allProducts;
    }



}
