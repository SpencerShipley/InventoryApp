package shipley.c492project.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import shipley.c492project.model.Inventory;
import shipley.c492project.model.Part;
import shipley.c492project.model.Product;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;


    public class MainForm implements Initializable {

        public MainForm(){}

        /*Button for the add part button*/
        @FXML
        private Button addPartButton;

        /*Button for the modify part button*/
        @FXML
        private Button modifyPartButton;

        /*Button for the delete part button*/
        @FXML
        private Button deletePartButton;

        /*Button for the add product button*/
        @FXML
        private Button addProductButton;

        /*Button for the modify product button*/
        @FXML
        private Button modifyProductButton;

        /*Button for the delete product button*/
        @FXML
        private Button deleteProductButton;

        /*Button for the exit button*/
        @FXML
        private Button exitButton;

        /*TextField for the part search*/
        @FXML
        private TextField searchPart;

        /*TextField for the product search*/
        @FXML
        private TextField searchProduct;

        /*TableColumn for the part inventory column*/
        @FXML
        private TableColumn<Part, Integer> partInventoryColumn;

        /*TableColumn for the part price column*/
        @FXML
        private TableColumn<Part, Double> partPriceColumn;

        /*TableColumn for the part ID column*/
        @FXML
        private TableColumn<Part, Integer> partIdColumn;

        /*TableColumn for the part name column*/
        @FXML
        private TableColumn<Part, String> partNameColumn;

        /*TableColumn for the product inventory column*/
        @FXML
        private TableColumn<Product, Integer> productInventoryColumn;

        /*TableColumn for the product price column*/
        @FXML
        private TableColumn<Product, Integer> productPriceColumn;

        /*TableColumn for the product ID column*/
        @FXML
        private TableColumn<Product, Integer> productIdColumn;

        /*TableColumn for the product name column*/
        @FXML
        private TableColumn<Product, String> productNameColumn;

        /*TableView for the part table*/
        @FXML
        private TableView<Part> partTableView;

        /*TableView for the product table*/
        @FXML
        private TableView<Product> productTableView;

    /*
    * Creates selectdPart to provide data for the ModifyPartForm
    * */

        private static Part selectedPart;

        public static Part getSelectedPart(){
            return selectedPart;
        }
        /*
         * Creates selectdProduct to provide data for the ModifyProductForm
         * */
        private static Product selectedProduct;

        public static Product getSelectedProduct(){
            return selectedProduct;
        }

        /*Opens the Add Part Form when the add part button is clicked*/
        public void onAddPartButton(ActionEvent actionEvent) throws IOException {
            Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/AddPartForm.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }

        /*Opens the Modify Part Form when the modify part button is clicked*/
        public void onModifyPartButton(ActionEvent actionEvent) throws IOException {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            selectedPart = partTableView.getSelectionModel().getSelectedItem();
            if (selectedPart == null) {
                warning.setContentText("Selected part is null");
                warning.showAndWait();
            } else {
                Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/ModifyPartForm.fxml"));
                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }
        }

        /*Deletes selected part when the delete part button is clicked*/
        public void onDeletePartButton(ActionEvent actionEvent) {
                Part selectedPart = partTableView.getSelectionModel().getSelectedItem();
                Alert warning = new Alert(Alert.AlertType.WARNING);
                if (selectedPart == null) {
                    warning.setContentText("Selected part is null");
                    warning.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Alert");
                    alert.setContentText("You are about to remove this part. Do you wish to continue?");
                    Optional<ButtonType> result = alert.showAndWait();

                    if (result.isPresent() && result.get() == ButtonType.OK) {
                        Inventory.deletePart(selectedPart);
                    }
                }
        }
        /*Searches for part based on ID or name*/
        public void onSearchPart(ActionEvent actionEvent) {
            ObservableList<Part> allParts = Inventory.getAllParts();
            ObservableList<Part> partsFound = FXCollections.observableArrayList();
            String partialSearch = searchPart.getText();

            for (Part part : allParts) {
                if (String.valueOf(part.getId()).contains(partialSearch) ||
                        part.getName().contains(partialSearch)) {
                    partsFound.add(part);
                }
            }
            partTableView.setItems(partsFound);

        }

        /*Opens the Add Product Form when the add product button is clicked*/
        public void onAddProductButton(ActionEvent actionEvent) throws IOException {
            Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/AddProductForm.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }

        /*Opens the Modify Product Form when the modify product button is clicked*/
        public void onModifyProductButton(ActionEvent actionEvent) throws IOException {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            selectedProduct = productTableView.getSelectionModel().getSelectedItem();
            try {
            if (selectedProduct == null) {
                warning.setContentText("Selected product is null");
                warning.showAndWait();
            } else {
                Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/ModifyProductForm.fxml"));
                Scene scene = new Scene(parent);
                Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }
            }
            catch (Throwable throwable) {
                System.out.println(throwable.toString());
                throwable.printStackTrace();
            }
        }

        /*Deletes selected part when the delete part button is clicked*/
        public void onDeleteProductButton(ActionEvent actionEvent) {
            Product selectedProduct = productTableView.getSelectionModel().getSelectedItem();
            Alert warning = new Alert(Alert.AlertType.WARNING);
            if (selectedProduct == null) {
                warning.setContentText("Selected product is null");
                warning.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Alert");
                alert.setContentText("You are about to remove this product. Do you wish to continue?");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK && selectedProduct.getAllAssociatedParts().size() == 0) {
                    Inventory.deleteProduct(selectedProduct);
                } else {
                    alert.setTitle("Alert");
                    warning.setContentText("Selected product has associated parts and cannot be deleted. " +
                            "Please remove associated parts and try again");
                    warning.showAndWait();
                }
            }
        }

        /*Searches for product based on ID or name*/
        public void onSearchProduct(ActionEvent actionEvent) {
            ObservableList<Product> allProducts = Inventory.getAllProducts();
            ObservableList<Product> productsFound = FXCollections.observableArrayList();
            String partialSearch = searchProduct.getText();

            for (Product product : allProducts) {
                if (String.valueOf(product.getId()).contains(partialSearch) ||
                        product.getName().contains(partialSearch)) {
                    productsFound.add(product);
                }
            }
            productTableView.setItems(productsFound);
        }

        /*Implements method in Initializable*/
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            partTableView.setItems(Inventory.getAllParts());
            partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
            partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
            partInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
            partPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

            productTableView.setItems(Inventory.getAllProducts());
            productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
            productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
            productInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
            productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        }

        /*Closes the application when the exit button is clicked*/
        public void onExitButton(ActionEvent actionEvent) {
            System.exit(0);
        }

    }
