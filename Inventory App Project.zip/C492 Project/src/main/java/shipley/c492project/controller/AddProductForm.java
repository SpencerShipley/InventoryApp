package shipley.c492project.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import shipley.c492project.model.Inventory;
import shipley.c492project.model.Part;
import shipley.c492project.model.Product;


import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.UUID;

public class AddProductForm implements Initializable {
    /*TextField for the product ID*/
    @FXML
    private TextField productID;

    /*TextField for the name*/
    @FXML
    private TextField name;

    /*TextField for the product inventory*/
    @FXML
    private TextField inventory;

    /*TextField for the product price*/
    @FXML
    private TextField price;

    /*TextField for the product max*/
    @FXML
    private TextField max;

    /*TextField for the product min*/
    @FXML
    private TextField min;

    /*Button for the add product button*/
    @FXML
    private Button addButton;

    /*Button for the remove product button*/
    @FXML
    private Button removeButton;

    /*Button for the save product button*/
    @FXML
    private Button saveButton;

    /*Button for the cancel button*/
    @FXML
    private Button cancelButton;

    /*TextField for the search*/
    @FXML
    private TextField search;

    /*TableView for the part table*/
    @FXML
    private TableView<Part> partTable;

    /*TableView for the associated part table*/
    @FXML
    private TableView<Part> associatedPartTable;

    /*Table Column for the part ID column*/
    @FXML
    private TableColumn<Part, Integer> partIDColumn;

    /*Table Column for the part name column*/
    @FXML
    private TableColumn<Part, String> partName;

    /*Table Column for the part inventory column*/
    @FXML
    private TableColumn<Part, Integer> partInventory;

    /*Table Column for the part price column*/
    @FXML
    private TableColumn<Part, Double> partPrice;

    /*Table Column for the associated part ID column*/
    @FXML
    private TableColumn<Part, Integer> associatedID;

    /*Table Column for the associated part name column*/
    @FXML
    private TableColumn<Part, String> associatedName;

    /*Table Column for the associated part inventory column*/
    @FXML
    private TableColumn<Part, Integer> associatedInventory;

    /*Table Column for the associated part price column*/
    @FXML
    private TableColumn<Part, Double> associatedPrice;

    /*Associated Parts List*/
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    /*FUTURE ENHANCEMENT Creates a product ID for each entry using a
    Universally Unique Identifier. This would be good for large inventories,
    but the ID becomes difficult to read. If easily readable IDs are needed
     in the future, this could be changed to an incrementally increased function*/
    @FXML
    void onProductID(ActionEvent actionEvent) {
        productID.setText(uniqueID);
    }
    @FXML
    String uniqueID = UUID.randomUUID().toString();

    /*Closes the window*/
    @FXML
    private void closeWindow(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/MainForm.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /*Closes window when the user clicks the cancel button*/
    @FXML
    void onCancelButton(ActionEvent actionEvent) throws IOException  {
        closeWindow(actionEvent);
    }

    /*Saves inputted data and creates a product if it passes the input validation.
    * Closes the window after saving.*/
    @FXML
    void onSaveButton(ActionEvent actionEvent) throws IOException {
        String id = productID.getText();
        String tempName = name.getText();
        Double tempPrice = Double.parseDouble(price.getText());
        int tempStock = Integer.parseInt(inventory.getText());
        int tempMin = Integer.parseInt(min.getText());
        int tempMax = Integer.parseInt(max.getText());
        Alert warning = new Alert(Alert.AlertType.WARNING);
        if (tempMin > tempMax) {
            warning.setTitle("Alert");
            warning.setContentText("Min must be less than Max");
            warning.showAndWait();
        } else if (tempMin > tempStock || tempMax < tempStock) {
            warning.setTitle("Alert");
            warning.setContentText("Inventory must be within acceptable levels.");
            warning.showAndWait();
        } else {
                Product newProduct = new Product(id, tempName, tempPrice, tempStock, tempMin, tempMax);
                for (Part part : associatedParts){
                    newProduct.addAssociatedPart(part);
                }
                Inventory.addProduct(newProduct);
                closeWindow(actionEvent);
            }
    }

    /*Adds the selected part to associated part on clicking the add button. Displays warning
    * if null product is selected*/
    @FXML
    public void onAddButton(ActionEvent actionEvent) {
        Part selectedPart = partTable.getSelectionModel().getSelectedItem();
        Alert warning = new Alert(Alert.AlertType.WARNING);
        if(selectedPart == null){
            warning.setContentText("Selected part is null");
            warning.showAndWait();
        }
        else{
            associatedParts.add(selectedPart);
            associatedPartTable.setItems(associatedParts);
        }
    }

    /*Removes associated part on click of the remove button and after confirmation.
    * Displays error if selected part is null.*/
    @FXML
    public void onRemoveButton (ActionEvent actionEvent) {
        Part selectedPart = associatedPartTable.getSelectionModel().getSelectedItem();
        Alert warning = new Alert(Alert.AlertType.WARNING);
        if (selectedPart == null) {
            warning.setContentText("Selected part is null");
            warning.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert");
            alert.setContentText("You are about to remove this part. Do you wish to continue?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                associatedParts.remove(selectedPart);
                associatedPartTable.setItems(associatedParts);
            }
        }
    }

    /*Searches for part based on ID or name*/
    @FXML
    public void searchFunction(ActionEvent actionEvent) {
        ObservableList<Part> allParts = Inventory.getAllParts();
        ObservableList<Part> partsFound = FXCollections.observableArrayList();
        String partialSearch = search.getText();

        for (Part part : allParts) {
            if (String.valueOf(part.getId()).contains(partialSearch) ||
                    part.getName().contains(partialSearch)) {
                partsFound.add(part);
            }
        }
        partTable.setItems(partsFound);
    }

    /*implements method in Initializable*/
        public void initialize (URL url, ResourceBundle resourceBundle){
            partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
            partName.setCellValueFactory(new PropertyValueFactory<>("name"));
            partInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
            partPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
            partTable.setItems(Inventory.getAllParts());

            associatedID.setCellValueFactory(new PropertyValueFactory<>("id"));
            associatedName.setCellValueFactory(new PropertyValueFactory<>("name"));
            associatedInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
            associatedPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        }

        /*Ensures that the min is less than the max and that the inventory is between them.
        public boolean inputValidation () {
            Alert warning = new Alert(Alert.AlertType.WARNING);
            int minTemp = Integer.valueOf(min.getText());
            int maxTemp = Integer.valueOf(max.getText());
            int stockTemp = Integer.valueOf(inventory.getText());
            if (minTemp > maxTemp) {
                warning.setContentText("Min must be less than Max.");
                return false;
            }
            if (minTemp > stockTemp || maxTemp < stockTemp) {
                warning.setContentText("Inventory must be within acceptable levels.");
                return false;
            }
            return true;
        }
*/
    }
