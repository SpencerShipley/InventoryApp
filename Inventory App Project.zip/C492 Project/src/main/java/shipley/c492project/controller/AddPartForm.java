package shipley.c492project.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.*;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.stage.*;

import shipley.c492project.HelloApplication;
import shipley.c492project.model.Inventory;
import shipley.c492project.model.InHouse;
import shipley.c492project.model.Outsourced;

import java.util.UUID;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;




public class AddPartForm implements Initializable {
    /*TextField for machineId and Company name*/
    @FXML
    private TextField machineID;

    /*Label for machineId and Company name*/
    @FXML
    private Label machineIdLabel;

    /*RadioButton for the inHouse selection*/
    @FXML
    private RadioButton inHouse;

    /*RadioButton for the outsourced selection*/
    @FXML
    private RadioButton outsourced;

    /*TextField for part ID*/
    @FXML
    private TextField partID;

    /*TextField for name*/
    @FXML
    private TextField name;

    /*TextField for inventory*/
    @FXML
    private TextField inventory;

    /*TextField for Price/Cost*/
    @FXML
    private TextField priceCost;

    /*TextField for max*/
    @FXML
    private TextField max;

    /*TextField for min*/
    @FXML
    private TextField min;

    /*TextField for company name*/
    @FXML
    private TextField companyName;

    /*Button for save button*/
    @FXML
    private Button saveButton;

    /*Button for cancel button*/
    @FXML
    private Button cancelButton;

    /*Implements method in Initializable*/
@Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    inHouse.setSelected(true);
    }

    /*Sets machineIdLabel to "Machine ID" when the inHouse radio button is selected*/
@FXML
    void onInHouse(ActionEvent actionEvent) {
    machineIdLabel.setText("Machine ID");
    }

    /*Sets machineIdLabel to "Company Name" when the outsourced radio button is selected*/
@FXML
    void onOutsourced(ActionEvent actionEvent) {
        machineIdLabel.setText("Company Name");
    }

    /*FUTURE ENHANCEMENT Creates a part ID for each entry using a
    Universally Unique Identifier. This would be good for large inventories,
    but the ID becomes difficult to read. If easily readable IDs are needed
     in the future, this could be changed to an incrementally increased function*/
@FXML
    void onPartID(ActionEvent actionEvent) {
    partID.setText(uniqueID);
    }
@FXML
    String uniqueID = UUID.randomUUID().toString();

    /*Saves part information and creates a part if it passes the input validation.
    If the inHouse radio button is selected, it will save with a machine ID.
     Otherwise, it will save with a company name.*/
@FXML
    public void onSaveButton(ActionEvent actionEvent) throws IOException {
    Alert warning = new Alert(Alert.AlertType.WARNING);
    boolean inHouseSelect = inHouse.isSelected();
    String id = partID.getText();
    String tempName = name.getText();
    Double tempPriceCost = Double.parseDouble(priceCost.getText());
    int tempStock = Integer.parseInt(inventory.getText());
    int tempMin = Integer.parseInt(min.getText());
    int tempMax = Integer.parseInt(max.getText());
    boolean validation1 = false;
    boolean validation2 = false;
    if (tempMin > tempMax) {
        warning.setTitle("Alert");
        warning.setContentText("Min must be less than Max.");
        warning.showAndWait();
        validation1 = false;
    } else {
        validation1 = true;
    }
    if (tempMin > tempStock || tempMax < tempStock) {
        warning.setTitle("Alert");
        warning.setContentText("Min must be less than Max.");
        warning.showAndWait();
        validation2 = false;
    } else {
        validation2 = true;
    }
    if (validation1 && validation2) {
            if (inHouseSelect) {
                int tempMachineId = Integer.parseInt(machineID.getText());
                Inventory.addPart(new InHouse(id, tempName, tempPriceCost, tempStock, tempMin, tempMax, tempMachineId));
            } else {
                String tempCompanyName = machineID.getText();
                Inventory.addPart(new Outsourced(id, tempName, tempPriceCost, tempStock, tempMin, tempMax, tempCompanyName));
            }
            closeWindow(actionEvent);
        }
}

    /*Closes window and returns to MainForm*/
@FXML
    private void closeWindow(ActionEvent actionEvent) throws IOException {
    Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/MainForm.fxml"));
    Scene scene = new Scene(parent);
    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
    stage.setScene(scene);
    stage.show();
    }

    /*Closes window when the cancel button is clicked.*/
@FXML
    void onCancelButton(ActionEvent actionEvent) throws IOException {
    closeWindow(actionEvent);
    }

    /*Ensures that the min is less than the max and that the inventory is between them.*/
    /*
    @FXML
    public boolean inputValidation() {
        Alert warning = new Alert(Alert.AlertType.WARNING);
        int minTemp = Integer.valueOf(min.getText());
        int maxTemp = Integer.valueOf(max.getText());
        int inventoryTemp = Integer.valueOf(inventory.getText());
        if (minTemp > maxTemp) {
            warning.setContentText("Min must be less than Max.");
            return false;
        }
        if (minTemp > inventoryTemp || maxTemp < inventoryTemp) {
            warning.setContentText("Inventory must be within acceptable levels.");
            return false;
        }
        return true;
    }
*/

}
