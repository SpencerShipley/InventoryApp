package shipley.c492project.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import shipley.c492project.model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.UUID;

public class ModifyPartForm implements Initializable {
    /*TextField for machineId and Company name*/
    @FXML
    private TextField machineId;

    /*Label for machineId and Company name*/
    @FXML
    private Label machineIdLabel;

    /*RadioButton for the inHouse selection*/
    @FXML
    private RadioButton inHouse;

    /*RadioButton for the outsourced selection*/
    @FXML
    private RadioButton outsourced;

    /*TextField for part ID*/
    @FXML
    private TextField partID;

    /*TextField for name*/
    @FXML
    private TextField name;

    /*TextField for inventory*/
    @FXML
    private TextField inventory;

    /*TextField for Price/Cost*/
    @FXML
    private TextField priceCost;

    /*TextField for max*/
    @FXML
    private TextField max;

    /*TextField for min*/
    @FXML
    private TextField min;

    /*TextField for company name*/
    @FXML
    private TextField companyName;

    /*Button for save button*/
    @FXML
    private Button saveButton;

    /*Button for cancel button*/
    @FXML
    private Button cancelButton;

    /*Creates a variable for user selection*/
    private Part userSelection;

    /*Closes window*/
    @FXML
    private void closeWindow(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(getClass().getResource("/shipley/c492project/MainForm.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /*Closes window when the cancel button is clicked.*/
    @FXML
    void onCancelButton(ActionEvent actionEvent) throws IOException {
        closeWindow(actionEvent);
    }

    /*Sets machineIdLabel to "Machine ID" when the inHouse radio button is selected*/
    @FXML
    void onInHouse(ActionEvent event) {
        machineIdLabel.setText("Machine ID");
    }

    /*Sets machineIdLabel to "Company Name" when the outsourced radio button is selected*/
    @FXML
    void onOutsourced(ActionEvent event) {
        machineIdLabel.setText("Company Name");
    }

    /*Saves part information and creates a part if it passes the input validation.
    If the inHouse radio button is selected, it will save with a machine ID.
     Otherwise, it will save with a company name.*/
    @FXML
    void onSaveButton(ActionEvent actionEvent) throws IOException {
        boolean inHouseSelect = inHouse.isSelected();
        String id = userSelection.getId();
        String tempName = name.getText();
        Double tempPriceCost = Double.parseDouble(priceCost.getText());
        int tempStock = Integer.parseInt(inventory.getText());
        int tempMin = Integer.parseInt(min.getText());
        int tempMax = Integer.parseInt(max.getText());
        if (inputValidation()) {
            if (inHouseSelect) {
                int tempMachineId = Integer.parseInt(machineId.getText());
                Inventory.addPart(new InHouse(id, tempName, tempPriceCost, tempStock, tempMin, tempMax, tempMachineId));
            } else {
                String tempCompanyName = machineId.getText();
                Inventory.addPart(new Outsourced(id, tempName, tempPriceCost, tempStock, tempMin, tempMax, tempCompanyName));
            }
            Inventory.deletePart(userSelection);
            closeWindow(actionEvent);
        }
    }

    /*Ensures that the min is less than the max and that the inventory is between them.*/
    @FXML
    public boolean inputValidation() {
        Alert warning = new Alert(Alert.AlertType.WARNING);
        int minTemp = Integer.valueOf(min.getText());
        int maxTemp = Integer.valueOf(max.getText());
        int inventoryTemp = Integer.valueOf(inventory.getText());
        if (minTemp > maxTemp) {
            warning.setTitle("Alert");
            warning.setContentText("Min must be less than Max.");
            warning.showAndWait();
            return false;
        }
        if (minTemp > inventoryTemp || maxTemp < inventoryTemp) {
            warning.setTitle("Alert");
            warning.setContentText("Inventory must be within acceptable levels.");
            warning.showAndWait();
            return false;
        }
        return true;
    }
//this is where you left off
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        userSelection = MainForm.getSelectedPart();

        if (userSelection instanceof InHouse) {
            inHouse.setSelected(true);
            machineIdLabel.setText("Machine ID");
            machineId.setText(String.valueOf(((InHouse) userSelection).getMachineId()));
        }

        if (userSelection instanceof Outsourced){
            outsourced.setSelected(true);
            machineIdLabel.setText("Company Name");
            machineId.setText(((Outsourced) userSelection).getCompanyName());
        }

        partID.setText(String.valueOf(userSelection.getId()));
        name.setText(userSelection.getName());
        inventory.setText(String.valueOf(userSelection.getStock()));
        priceCost.setText(String.valueOf(userSelection.getPrice()));
        max.setText(String.valueOf(userSelection.getMax()));
        min.setText(String.valueOf(userSelection.getMin()));

    }
}
