package shipley.c492project;
import javafx.application.*;
import javafx.fxml.*;
import javafx.scene.Parent;
import javafx.scene.*;
import javafx.stage.*;


import java.io.*;
import java.net.URL;

public class HelloApplication extends Application {

        @Override
        public void start (Stage stage) throws IOException {
        FXMLLoader fxmlloader = new FXMLLoader(HelloApplication.class.getResource("/shipley/c492project/MainForm.fxml"));
        Scene scene = new Scene(fxmlloader.load());
        stage.setTitle("Hello");
        stage.setScene(scene);
        stage.show();

    }

        public static void main (String[] args){
            try {
                launch();
        }
              catch (Throwable throwable) {
              System.out.println(throwable.toString());
              throwable.printStackTrace();
         }
    }
}

//