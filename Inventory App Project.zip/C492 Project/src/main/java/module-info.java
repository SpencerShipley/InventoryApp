module shipley.c492project {
    requires javafx.controls;
    requires javafx.fxml;


    opens shipley.c492project to javafx.fxml;
    exports shipley.c492project;
    exports shipley.c492project.controller;
    opens shipley.c492project.controller to javafx.fxml;
    exports shipley.c492project.model;
    opens shipley.c492project.model to javafx.fxml;
}